package project2;

import java.util.*;

public class Sort {
	private Eatery[] temp_list = new Eatery[80]; //�պ� ���Ŀ� ���� �ӽ� Eatery[] �����				
	public Sort() {}
	
	//�̸� ���Ŀ� ���� ����Ʈ
	public ArrayList<Eatery> get_name_quicksort(ArrayList<Eatery> array) {				
		ArrayList<Eatery> temp_eat = new ArrayList<Eatery>();
		for(int i=0;i<array.size();i++) {
			temp_eat.add(array.get(i));
		}
		name_quicksort(temp_eat, 0, temp_eat.size()-1);
		return temp_eat;
	}
	
	//��ġ ���Ŀ� ���� ����Ʈ
	public ArrayList<Eatery> get_locate_quicksort(ArrayList<Eatery> array) {										
		ArrayList<Eatery> temp_eat = new ArrayList<Eatery>();
		for(int i=0;i<array.size();i++) {
			temp_eat.add(array.get(i));
		}
		locate_quicksort(temp_eat, 0, temp_eat.size()-1);
		return temp_eat;
	}

	//�̸� ����Ʈ
	public void name_quicksort(ArrayList<Eatery> array, int left, int right) {
		int i,j;
		Eatery pivot,tmp;
		if(left<right) {
			i=left; j=right;
			pivot = array.get((left+right)/2);
			do {
				while(array.get(i).getName().compareTo(pivot.getName()) < 0) i++;
				while(pivot.getName().compareTo(array.get(j).getName()) < 0 ) j--;
				if(i <= j) {
					tmp = array.get(i);
					array.set(i,array.get(j));
					array.set(j,tmp);
					i++;j--;
				}
			} while(i<=j);
			
			if (left < j) name_quicksort(array, left, j);
			if (i < right) name_quicksort(array, i, right);
		}
	}
	
	//��ġ ����Ʈ
	public void locate_quicksort(ArrayList<Eatery> array, int left, int right) {
		int i,j;
		Eatery pivot,tmp;
		if(left<right) {
			i=left; j=right;
			pivot = array.get((left+right)/2);
			do {
				while(array.get(i).getLocation().compareTo(pivot.getLocation()) < 0) i++;
				while(pivot.getLocation().compareTo(array.get(j).getLocation()) < 0 ) j--;
				if(i <= j) {
					tmp = array.get(i);
					array.set(i,array.get(j));
					array.set(j,tmp);
					i++;j--;
				}
			} while(i<=j);
			
			if (left < j) locate_quicksort(array, left, j);
			if (i < right) locate_quicksort(array, i, right);
		}
	}
	
	//���� �պ�����
	public void getmergesort(ArrayList<Eatery> array) {										
		mergesort(array, 0, array.size()-1);
	}
	
	//������Ʈ
	public void mergesort(ArrayList<Eatery> array, int low, int high) {
		if(low<high) {
			int mid = (low+high)/2;
			mergesort(array,low,mid);
			mergesort(array,mid+1,high);
			merge(array,low,mid,high);
		}
	}
		

	//���� - ��������
	public void merge(ArrayList<Eatery> array, int low, int mid, int high) {
		
		int i, j, k, l;
		
		i = low; j = mid+1; k = low;
		while(i<= mid && j <= high) {
			
			if(array.get(i).getRating() > array.get(j).getRating()) {
				temp_list[k++] = array.get(i++);
			}
			else {
				temp_list[k++] = array.get(j++);
			}
		}
			
		if(mid < i) {
			for (l = j; l <= high; l++) {
				temp_list[k++] = array.get(l);
			}
		}
		else {
			for (l = i; l <= mid; l++) {
				temp_list[k++] = array.get(l);
			}
		}
		for(l = low; l <= high; l++) {
			array.set(l, temp_list[l]);
		}
	}
}